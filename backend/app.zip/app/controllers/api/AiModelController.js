/**
 * AiModelController - AI 大模型管理接口
 * GET    /ai-models                          前台获取可用模型列表（无需鉴权，不含敏感字段）
 * GET    /admin/ai-models                    管理员获取全量模型列表（含敏感字段）
 * POST   /admin/ai-models                    管理员新建模型
 * PUT    /admin/ai-models/:id               管理员更新模型
 * DELETE /admin/ai-models/:id               管理员删除模型
 */
const AiModel = require('#models/AiModel');
const AigcService = require('#services/aigc.service');
const { success, fail, serverError } = require('#factories/responses/aigc');

module.exports = AiModelController;

function AiModelController() {

	// GET /api/ai-models - 前台获取激活的模型列表（不暴露 api_key、api_endpoint）
	const getPublicModels = async (req, res) => {
		try {
			// 支持按 type 过滤：?type=image 或 ?type=video
			const where = { is_active: 1 };
			if (req.query.type && ['image', 'video'].includes(req.query.type)) {
				const { Op } = require('sequelize');
				where.type = { [Op.in]: [req.query.type, 'both'] };
			}

			const models = await AiModel.findAll({
				where,
				order: [['sort_order', 'ASC'], ['createdAt', 'ASC']],
				// 安全：不返回敏感配置字段
			attributes: ['id', 'name', 'subtitle', 'type', 'model_name', 'sort_order', 'points_cost']
			});

			// 附加每个模型支持的前端可选参数能力（用于前端动态渲染选项）
			const result = models.map(m => ({
				...m.toJSON(),
				capabilities: AigcService.getModelCapabilities(m.model_name)
			}));

			return success(res, '获取成功', { models: result });
		} catch (error) {
			console.error('[AiModelController.getPublicModels]', error);
			return serverError(res);
		}
	};

	// GET /api/admin/ai-models - 管理员获取全量列表（含敏感字段）
	const getModels = async (req, res) => {
		try {
			const models = await AiModel.findAll({
				order: [['sort_order', 'ASC'], ['createdAt', 'ASC']]
			});
			return success(res, '获取成功', { models });
		} catch (error) {
			console.error('[AiModelController.getModels]', error);
			return serverError(res);
		}
	};

	// POST /api/admin/ai-models - 新建模型
	const createModel = async (req, res) => {
		const { name, subtitle, type, api_key, api_endpoint, model_name, sort_order = 0, is_active = 1, points_cost = 0 } = req.body;

		if (!name || !name.trim()) return fail(res, '模型显示名称不能为空');
		if (!['image', 'video', 'both'].includes(type)) return fail(res, 'type 只能为 image / video / both');
		if (!model_name || !model_name.trim()) return fail(res, '模型标识符 model_name 不能为空');
		if (isNaN(parseInt(points_cost)) || parseInt(points_cost) < 0) return fail(res, '积分额度必须为非负整数');

		try {
			const model = await AiModel.create({
				name: String(name).trim(),
				subtitle: subtitle ? String(subtitle).trim() : null,
				type,
				api_key: api_key || null,
				api_endpoint: api_endpoint || null,
				model_name: String(model_name).trim(),
				sort_order: parseInt(sort_order) || 0,
				is_active: is_active ? 1 : 0,
				points_cost: parseInt(points_cost)
			});

			return success(res, '模型创建成功', { id: model.id });
		} catch (error) {
			console.error('[AiModelController.createModel]', error);
			return serverError(res);
		}
	};

	// PUT /api/admin/ai-models/:id - 更新模型
	const updateModel = async (req, res) => {
		const { id } = req.params;
		const { name, subtitle, type, api_key, api_endpoint, model_name, sort_order, is_active, points_cost } = req.body;

		if (type !== undefined && !['image', 'video', 'both'].includes(type)) {
			return fail(res, 'type 只能为 image / video / both');
		}
		if (points_cost !== undefined && (isNaN(parseInt(points_cost)) || parseInt(points_cost) < 0)) {
			return fail(res, '积分额度必须为非负整数');
		}

		try {
			const model = await AiModel.findByPk(id);
			if (!model) return fail(res, '模型不存在', 'NOT_FOUND', 404);

			if (name !== undefined) model.name = String(name).trim();
			if (subtitle !== undefined) model.subtitle = subtitle ? String(subtitle).trim() : null;
			if (type !== undefined) model.type = type;
			if (api_key !== undefined) model.api_key = api_key || null;
			if (api_endpoint !== undefined) model.api_endpoint = api_endpoint || null;
			if (model_name !== undefined) model.model_name = String(model_name).trim();
			if (sort_order !== undefined) model.sort_order = parseInt(sort_order) || 0;
			if (is_active !== undefined) model.is_active = is_active ? 1 : 0;
			if (points_cost !== undefined) model.points_cost = parseInt(points_cost);

			await model.save();
			return success(res, '模型更新成功');
		} catch (error) {
			console.error('[AiModelController.updateModel]', error);
			return serverError(res);
		}
	};

	// DELETE /api/admin/ai-models/:id - 删除模型（物理删除）
	const deleteModel = async (req, res) => {
		const { id } = req.params;
		try {
			const model = await AiModel.findByPk(id);
			if (!model) return fail(res, '模型不存在', 'NOT_FOUND', 404);

			await model.destroy();
			return success(res, '模型已删除');
		} catch (error) {
			console.error('[AiModelController.deleteModel]', error);
			return serverError(res);
		}
	};

	return {
		getPublicModels,
		getModels,
		createModel,
		updateModel,
		deleteModel
	};
}
