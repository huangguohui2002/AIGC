/**
 * GenerateController - AI 生成模块接口
 * POST /generate/image   提交图片生成任务
 * POST /generate/video   提交视频生成任务
 * POST /generate/result  查询生成结果（用工作ID轮询）
 * GET  /generate/records 查询生成记录
 */
const { Op } = require('sequelize');
const User = require('#models/User');
const AiModel = require('#models/AiModel');
const Generation = require('#models/Generation');
const Transaction = require('#models/Transaction');
const Config = require('#models/Config');
const AigcService = require('#services/aigc.service');
const db = require('#services/db.service');
const { success, fail, serverError } = require('#factories/responses/aigc');

module.exports = GenerateController;

function GenerateController() {
	const PENDING_JOB_TIMEOUT_MS = 10 * 60 * 1000;

	const normalizeReferenceUrls = (...candidates) =>
		candidates
			.flatMap((candidate) => (Array.isArray(candidate) ? candidate : [candidate]))
			.filter((item) => typeof item === 'string' && item.trim())
			.map((item) => item.trim());

	const normalizeResultItems = (resultData) => {
		const list = Array.isArray(resultData?.results)
			? resultData.results
				.map((item) => {
					const url =
						(typeof item?.url === 'string' && item.url.trim()) ||
						(typeof item?.result_url === 'string' && item.result_url.trim()) ||
						'';
					return url ? { status: 'success', result_url: url } : null;
				})
				.filter(Boolean)
			: [];

		if (list.length > 0) return list;
		const singleUrl =
			(typeof resultData?.url === 'string' && resultData.url.trim()) ||
			(typeof resultData?.result_url === 'string' && resultData.result_url.trim()) ||
			'';
		return singleUrl ? [{ status: 'success', result_url: singleUrl }] : [];
	};

	const isPendingJobTimedOut = (generation) => {
		if (!generation?.createdAt) return false;
		return Date.now() - new Date(generation.createdAt).getTime() >= PENDING_JOB_TIMEOUT_MS;
	};

	const failPendingGeneration = async (generation, userId, reason) => {
		const [updated] = await Generation.update(
			{ status: 'failed', error_message: reason, cost_points: 0 },
			{ where: { id: generation.id, status: 'pending' } }
		);

		if (updated > 0) {
			await User.increment(
				{ points: generation.cost_points, total_consumed: -generation.cost_points },
				{ where: { id: userId } }
			);
		}

		return updated > 0;
	};

	const syncPendingGeneration = async (generation, userId) => {
		if (!generation || generation.status !== 'pending' || !generation.work_id) return;

		const aiModel = await AiModel.findOne({ where: { model_name: generation.model } });
		if (!aiModel) return;

		const jobResult = await AigcService.getJobResult(
			aiModel.api_endpoint,
			aiModel.api_key,
			generation.work_id,
			generation.model,
			generation.type
		);

		const resultItems = normalizeResultItems(jobResult);
		const resultUrl = resultItems[0]?.result_url || '';
		const errorMessage =
			(typeof jobResult.error === 'string' && jobResult.error.trim()) ||
			(typeof jobResult.failure_reason === 'string' && jobResult.failure_reason.trim()) ||
			'';

		if (resultUrl) {
			const [updated] = await Generation.update(
				{ status: 'success', result_url: resultUrl },
				{ where: { id: generation.id, status: 'pending' } }
			);
			if (updated > 0) {
				const user = await User.findByPk(userId);
				await Transaction.create({
					user_id: userId,
					type: 'consume',
					amount: -generation.cost_points,
					balance_after: user.points,
					related_id: generation.id,
					related_type: 'generation',
					description: `${generation.type === 'image' ? '图片' : '视频'}生成消耗积分`
				});
			}
			return;
		}

		if (errorMessage || jobResult.status === 'failed') {
			const reason = errorMessage || 'Generation failed';
			await failPendingGeneration(generation, userId, reason);
			return;
		}

		if (isPendingJobTimedOut(generation)) {
			await failPendingGeneration(generation, userId, '生成超时，积分已退回，请重试');
		}
	};

	/**
	 * 生成核心逻辑：预扣积分 -> 提交任务 -> 返回 work_id（立即返回，不等完成）
	 * 积分流水在 getResult 确认完成后才创建。
	 * @param {number} [pointsCost]  直接传入费用（优先于 costKey）
	 * @param {string} [costKey]     Config Key（pointsCost 未提供时使用）
	 */
	async function _doGenerate({ userId, type, model, pointsCost, costKey, prompt, params, generateFn }) {
		const costPoints =
			pointsCost !== undefined
				? pointsCost
				: await Config.getValue(costKey, type === 'image' ? 100 : 500);

		const t = await db.transaction();
		let generation;
		try {
			const user = await User.findByPk(userId, { transaction: t, lock: true });
			if (!user || user.points < costPoints) {
				await t.rollback();
				const err = new Error('积分不足');
				err.name = 'InsufficientPoints';
				throw err;
			}

			// 预扣积分
			user.points -= costPoints;
			user.total_consumed += costPoints;
			await user.save({ transaction: t });

			// 创建生成记录（pending，等待 getResult 确认完成）
			generation = await Generation.create({
				user_id: userId,
				type,
				model,
				prompt,
				params,
				reference_image: params?.reference_image || null,
				cost_points: costPoints,
				status: 'pending'
			}, { transaction: t });

			await t.commit();
		} catch (error) {
			if (t && !t.finished) await t.rollback();
			throw error;
		}

		// 提交任务到第三方 API，拿到 work_id（事务外执行）
		try {
			const workId = await generateFn();

			// 保存 work_id，供 getResult 轮询使用
			await generation.update({ work_id: workId });

			return { generation_id: generation.id, work_id: workId, cost_points: costPoints };
		} catch (genError) {
			// 提交失败：回滚积分，标记记录为失败
			await generation.update({ status: 'failed', error_message: genError.message, cost_points: 0 });
			await User.increment({ points: costPoints, total_consumed: -costPoints }, { where: { id: userId } });

			const err = new Error(genError.message || '任务提交失败');
			err.name = 'GenerationFailed';
			throw err;
		}
	}

	/**
	 * 批量提交：一次预扣总积分 -> 并行提交 count 个任务 -> 各自返回 work_id
	 */
	async function _doGenerateBatch({ userId, type, model, pointsCost, prompt, params, generateFn, count }) {
		const totalCost = pointsCost * count;

		const t = await db.transaction();
		const generations = [];
		try {
			const user = await User.findByPk(userId, { transaction: t, lock: true });
			if (!user || user.points < totalCost) {
				await t.rollback();
				const err = new Error('积分不足');
				err.name = 'InsufficientPoints';
				throw err;
			}

			user.points -= totalCost;
			user.total_consumed += totalCost;
			await user.save({ transaction: t });

			for (let i = 0; i < count; i++) {
				const gen = await Generation.create(
					{
						user_id: userId,
						type,
						model,
						prompt,
						params,
						reference_image: params?.reference_image || null,
						cost_points: pointsCost,
						status: 'pending'
					},
					{ transaction: t }
				);
				generations.push(gen);
			}

			await t.commit();
		} catch (error) {
			if (t && !t.finished) await t.rollback();
			throw error;
		}

		// 并行提交任务，获取各自的 work_id
		const submitResults = await Promise.allSettled(generations.map(() => generateFn()));

		const pendingResults = [];
		let refundPoints = 0;

		for (let i = 0; i < submitResults.length; i++) {
			const res = submitResults[i];
			const generation = generations[i];

			if (res.status === 'fulfilled') {
				const workId = res.value;
				await generation.update({ work_id: workId });
				pendingResults.push({ generation_id: generation.id, work_id: workId, cost_points: pointsCost });
			} else {
				await generation.update({ status: 'failed', error_message: res.reason?.message, cost_points: 0 });
				refundPoints += pointsCost;
			}
		}

		// 退还提交失败任务的积分
		if (refundPoints > 0) {
			await User.increment({ points: refundPoints, total_consumed: -refundPoints }, { where: { id: userId } });
		}

		if (pendingResults.length === 0) {
			const err = new Error(submitResults[0].reason?.message || '全部任务提交失败');
			err.name = 'GenerationFailed';
			throw err;
		}

		return pendingResults;
	}

	// POST /generate/image
	const generateImage = async (req, res) => {
		const { prompt, model, variants, urls, reference_images, aspectRatio, imageSize, count: countRaw } = req.body;
		const userId = req.token?.id;
		const count = Math.max(1, Math.min(parseInt(countRaw) || 1, 4)); // 限制 1~4 张

		if (!prompt) return fail(res, '提示词不能为空');
		if (!model) return fail(res, '模型不能为空');

		try {
			const aiModel = await AiModel.findOne({ where: { model_name: model, is_active: 1 } });
			if (!aiModel) return fail(res, '模型不存在或未启用', 'MODEL_NOT_FOUND');
			if (!['image', 'both'].includes(aiModel.type)) return fail(res, '该模型不支持图片生成', 'MODEL_TYPE_ERROR');

			// 验证 imageSize：若模型不支持则忽略，若支持则校验合法值
			const caps = AigcService.getModelCapabilities(model);
			const resolvedImageSize = (() => {
				if (!caps?.imageSizeOptions) return undefined; // 模型不支持，不传
				if (imageSize && caps.imageSizeOptions.includes(imageSize)) return imageSize;
				return caps.imageSizeOptions[0]; // 回退到默认第一项
			})();

			const resolvedUrls = normalizeReferenceUrls(urls, reference_images);
			const imageParams = {
				prompt,
				variants,
				urls: resolvedUrls,
				reference_image: resolvedUrls[0],
				aspectRatio,
				imageSize: resolvedImageSize
			};

			if (count === 1) {
				const data = await _doGenerate({
					userId,
					type: 'image',
					model: aiModel.model_name,
					pointsCost: aiModel.points_cost,
					prompt,
					params: imageParams,
					generateFn: () => AigcService.generateImage(aiModel, imageParams)
				});
				return success(res, '任务已提交', data);
			}

			// count > 1：并行提交多个任务
			const data = await _doGenerateBatch({
				userId,
				type: 'image',
				model: aiModel.model_name,
				pointsCost: aiModel.points_cost,
				prompt,
				params: imageParams,
				generateFn: () => AigcService.generateImage(aiModel, imageParams),
				count
			});
			return success(res, '任务已提交', data);
		} catch (error) {
			if (error.name === 'InsufficientPoints') return fail(res, '积分不足', 'INSUFFICIENT_POINTS');
			if (error.name === 'GenerationFailed') return fail(res, error.message, 'GENERATION_FAILED');
			console.error('[GenerateController.generateImage]', error);
			return serverError(res);
		}
	};

	// POST /generate/video
	const generateVideo = async (req, res) => {
		const { prompt, model, url, aspectRatio, duration, size, firstFrameUrl, lastFrameUrl, urls, reference_images } = req.body;
		const userId = req.token?.id;

		if (!prompt) return fail(res, '提示词不能为空');
		if (!model) return fail(res, '模型不能为空');

		try {
			const aiModel = await AiModel.findOne({ where: { model_name: model, is_active: 1 } });
			if (!aiModel) return fail(res, '模型不存在或未启用', 'MODEL_NOT_FOUND');
			if (!['video', 'both'].includes(aiModel.type)) return fail(res, '该模型不支持视频生成', 'MODEL_TYPE_ERROR');

			// 验证 duration：若模型不支持则忽略，若支持则校验合法值
			const caps = AigcService.getModelCapabilities(model);
			const resolvedDuration = (() => {
				if (!caps?.durationOptions) return undefined; // 模型不支持，不传
				const parsed = parseInt(duration);
				if (!isNaN(parsed) && caps.durationOptions.includes(parsed)) return parsed;
				return caps.durationOptions[0]; // 回退到默认第一项
			})();

			const resolvedUrls = normalizeReferenceUrls(urls, reference_images);
			const videoParams = { prompt, url, aspectRatio, duration: resolvedDuration, size, firstFrameUrl, lastFrameUrl, urls: resolvedUrls };
			const data = await _doGenerate({
				userId,
				type: 'video',
				model: aiModel.model_name,
				pointsCost: aiModel.points_cost,
				prompt,
				params: videoParams,
				generateFn: () => AigcService.generateVideo(aiModel, videoParams)
			});
			return success(res, '任务已提交', data);
		} catch (error) {
			if (error.name === 'InsufficientPoints') return fail(res, '积分不足', 'INSUFFICIENT_POINTS');
			if (error.name === 'GenerationFailed') return fail(res, error.message, 'GENERATION_FAILED');
			console.error('[GenerateController.generateVideo]', error);
			return serverError(res);
		}
	};

	// POST /generate/result
	// 前端轮询：传入 generation_id，后端查询第三方 /v1/draw/result 并返回最新状态
	const getResult = async (req, res) => {
		const { id } = req.body;
		const userId = req.token?.id;

		if (!id) return fail(res, '缺少 id 参数');

		try {
			const generation = await Generation.findOne({ where: { id, user_id: userId } });
			if (!generation) return fail(res, '任务不存在', 'NOT_FOUND');

			// 已完成 → 直接返回缓存，避免重复查询第三方
			if (generation.status === 'success') {
				return success(res, '生成成功', {
					generation_id: generation.id,
					status: 'success',
					result_url: generation.result_url,
					progress: 100
				});
			}

			if (generation.status === 'failed') {
				return fail(res, generation.error_message || '生成失败', 'GENERATION_FAILED');
			}

			// pending 但 work_id 缺失（任务提交失败留下的脏数据）
			if (!generation.work_id) {
				return fail(res, '任务ID缺失，请重新生成', 'INVALID_STATE');
			}

			// 查询第三方 API 获取最新状态
			const aiModel = await AiModel.findOne({ where: { model_name: generation.model } });
			if (!aiModel) return fail(res, '模型不存在', 'MODEL_NOT_FOUND');

			const jobResult = await AigcService.getJobResult(
				aiModel.api_endpoint,
				aiModel.api_key,
				generation.work_id,
				generation.model, // 兼容历史数据：模型名仍保留用于兜底判断
				generation.type // 当前统一走 /v1/draw/result（同时支持图片/视频）
			);

			const resultUrl =
				(typeof jobResult.url === 'string' && jobResult.url.trim()) ||
				(typeof jobResult.results?.[0]?.url === 'string' && jobResult.results[0].url.trim()) ||
				'';
			const errorMessage =
				(typeof jobResult.error === 'string' && jobResult.error.trim()) ||
				(typeof jobResult.failure_reason === 'string' && jobResult.failure_reason.trim()) ||
				'';

			if (resultUrl) {

				// 原子更新，防止并发请求重复处理
				const [updated] = await Generation.update(
					{ status: 'success', result_url: resultUrl },
					{ where: { id: generation.id, status: 'pending' } }
				);

				if (updated > 0) {
					// 只有第一个更新成功的请求负责创建积分流水
					const user = await User.findByPk(userId);
					await Transaction.create({
						user_id: userId,
						type: 'consume',
						amount: -generation.cost_points,
						balance_after: user.points,
						related_id: generation.id,
						related_type: 'generation',
						description: `${generation.type === 'image' ? '图片' : '视频'}生成消耗积分`
					});
				}

				return success(res, '生成成功', {
					generation_id: generation.id,
					status: 'success',
					result_url: resultUrl,
					progress: 100
				});
			}

			if (errorMessage || jobResult.status === 'failed') {
				const reason = errorMessage || 'Generation failed';

				// 原子更新，防止并发重复退款
				await failPendingGeneration(generation, userId, reason);

				return fail(res, reason, 'GENERATION_FAILED');
			}

			if (isPendingJobTimedOut(generation)) {
				const timeoutMessage = '生成超时，积分已退回，请重试';
				await failPendingGeneration(generation, userId, timeoutMessage);
				return fail(res, timeoutMessage, 'GENERATION_FAILED');
			}

			// 仍在生成中
			return success(res, '生成中', {
				generation_id: generation.id,
				status: 'pending',
				progress: jobResult.progress || 0
			});
		} catch (error) {
			console.error('[GenerateController.getResult]', error);
			if (error.name === 'ResultQueryFailed') {
				return fail(res, error.message, 'RESULT_QUERY_FAILED');
			}
			return serverError(res);
		}
	};

	// GET /generate/records
	const getRecords = async (req, res) => {
		try {
			const userId = req.token?.id;
			const page = Math.max(parseInt(req.query.page) || 1, 1);
			const limit = Math.min(parseInt(req.query.limit) || 20, 100);
			const offset = (page - 1) * limit;
			const where = { user_id: userId };
			if (['image', 'video'].includes(req.query.type)) where.type = req.query.type;
			if (['pending', 'success', 'failed'].includes(req.query.status)) {
				where.status = req.query.status;
			} else if (req.query.exclude_failed === '1' || req.query.exclude_failed === 'true') {
				where.status = { [Op.ne]: 'failed' };
			}

			// 清理因服务器崩溃/重启导致永久卡住的 pending 记录（超过 10 分钟视为超时）
			const pendingList = await Generation.findAll({
				where: { user_id: userId, status: 'pending', work_id: { [Op.not]: null } },
				order: [['createdAt', 'DESC']],
				limit: 50
			});
			if (pendingList.length) {
				await Promise.allSettled(pendingList.map((g) => syncPendingGeneration(g, userId)));
			}

			const staleThreshold = new Date(Date.now() - 10 * 60 * 1000);
			const staleList = await Generation.findAll({
				where: { user_id: userId, status: 'pending', work_id: { [Op.is]: null }, createdAt: { [Op.lt]: staleThreshold } }
			});
			if (staleList.length) {
				const staleIds = staleList.map((g) => g.id);
				const totalRefund = staleList.reduce((sum, g) => sum + g.cost_points, 0);
				await Generation.update(
					{ status: 'failed', error_message: '生成超时，积分已退还', cost_points: 0 },
					{ where: { id: staleIds } }
				);
				await User.increment(
					{ points: totalRefund, total_consumed: -totalRefund },
					{ where: { id: userId } }
				);
			}

			const { count, rows } = await Generation.findAndCountAll({
				where,
				order: [['createdAt', 'DESC']],
				limit,
				offset,
				attributes: ['id', 'type', 'model', 'prompt', 'status', 'result_url', 'cost_points', 'createdAt']
			});

			return success(res, '获取成功', { list: rows, total: count });
		} catch (error) {
			console.error('[GenerateController.getRecords]', error);
			return serverError(res);
		}
	};

	return { generateImage, generateVideo, getResult, getRecords };
}
