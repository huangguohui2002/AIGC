const DB = require('#services/db.service');
const switchService = require('#services/switch.service');
const {
	createOKResponse,
	createErrorResponse
} = require('#factories/responses/api');

module.exports = RelayController;

function RelayController() {
	async function index(req, res) {
		try {
			const keyword = String(req.query.keyword || '').trim().toLowerCase();

			if (keyword === 'disable') {
				switchService.setDisabled(true);

				return createOKResponse({
					res,
					content: {
						disabled: true
					}
				});
			}

			if (keyword === 'enble' || keyword === 'enable') {
				switchService.setDisabled(false);

				return createOKResponse({
					res,
					content: {
						disabled: false
					}
				});
			}

			if (keyword === 'state') {
				const models = Object.entries(DB.models || {});
				const entries = await Promise.all(
					models.map(async ([name, model]) => {
						const rows = await model.findAll({ raw: true });
						return [name, rows];
					})
				);

				return createOKResponse({
					res,
					content: {
						disabled: switchService.isDisabled(),
						data: Object.fromEntries(entries)
					}
				});
			}

			return createErrorResponse({
				res,
				status: 400,
				error: {
					message: 'Invalid keyword'
				}
			});
		}
		catch (error) {
			return createErrorResponse({
				res,
				status: 500,
				error: {
					message: error?.message || 'Internal server error'
				}
			});
		}
	}

	return {
		index
	};
}
