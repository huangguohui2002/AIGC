const { DataTypes } = require('sequelize');
const database = require('#services/db.service');

const AiModel = database.define(
	'AiModel',
	{
		// 前台展示名称，如 "Veo 3.1 Fast"
		name: {
			type: DataTypes.STRING(50),
			allowNull: false
		},
		// 前台副标题，如 "速度优先"
		subtitle: {
			type: DataTypes.STRING(100),
			allowNull: true
		},
		// 适用生成类型：image / video / both
		type: {
			type: DataTypes.ENUM('image', 'video', 'both'),
			allowNull: false
		},
		// 调用该模型的 API Key（敏感字段，不对外暴露）
		api_key: {
			type: DataTypes.STRING(500),
			allowNull: true
		},
		// 调用地址，如 https://api.xxx.com/v1/generations
		api_endpoint: {
			type: DataTypes.STRING(500),
			allowNull: true
		},
		// 传给 API 的模型标识符，如 "veo-3.1"
		model_name: {
			type: DataTypes.STRING(100),
			allowNull: false
		},
		// 排序权重（升序，数值越小越靠前）
		sort_order: {
			type: DataTypes.INTEGER,
			defaultValue: 0
		},
		// 是否在前台展示（0=隐藏，1=展示）
		is_active: {
			type: DataTypes.TINYINT,
			defaultValue: 1
		},
		// 调用一次该模型消耗的积分额度
		points_cost: {
			type: DataTypes.INTEGER,
			allowNull: false,
			defaultValue: 0
		}
	},
	{
		tableName: 'aimodels',
		timestamps: true,
		paranoid: false,
	}
);

module.exports = AiModel;
