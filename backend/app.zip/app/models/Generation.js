const { DataTypes } = require('sequelize');
const database = require('#services/db.service');

const Generation = database.define(
	'Generation',
	{
		user_id: {
			type: DataTypes.BIGINT,
			allowNull: false
		},
		type: {
			type: DataTypes.ENUM('image', 'video'),
			allowNull: false
		},
		model: {
			type: DataTypes.STRING(50),
			allowNull: false
		},
		prompt: {
			type: DataTypes.TEXT,
			allowNull: false
		},
		reference_image: {
			type: DataTypes.STRING(255),
			allowNull: true
		},
		params: {
			type: DataTypes.JSON,
			allowNull: true
		},
		work_id: {
			type: DataTypes.STRING(100),
			allowNull: true,
			comment: '第三方平台任务ID，用于轮询结果'
		},
		status: {
			type: DataTypes.ENUM('pending', 'success', 'failed'),
			defaultValue: 'pending'
		},
		result_url: {
			type: DataTypes.STRING(255),
			allowNull: true
		},
		cost_points: {
			type: DataTypes.INTEGER,
			allowNull: false
		},
		error_message: {
			type: DataTypes.TEXT,
			allowNull: true
		}
	},
	{
		tableName: 'generations',
		timestamps: true
	}
);

Generation.associate = (models) => {
	models.Generation.belongsTo(models.User, { foreignKey: 'user_id', as: 'user' });
};

module.exports = Generation;
