/*
 * Import all models, that you want to use in application.
 */
require('./User');
require('./DisabledRefreshToken');
require('./SmsCode');
require('./PointsPackage');
require('./Order');
require('./Transaction');
require('./Generation');
require('./Invite');
require('./Announcement');
require('./Config');
require('./AiModel');
require('./ExampleCategory');
require('./ExampleItem');
require('./ExampleImage');

// 建立 Example 模块关联关系（需在所有模型 require 完成后执行）
const ExampleCategory = require('./ExampleCategory');
const ExampleItem = require('./ExampleItem');
const ExampleImage = require('./ExampleImage');

ExampleCategory.hasMany(ExampleItem, { foreignKey: 'category_id', as: 'items' });
ExampleItem.belongsTo(ExampleCategory, { foreignKey: 'category_id', as: 'category' });
ExampleItem.hasMany(ExampleImage, { foreignKey: 'example_id', as: 'images' });
ExampleImage.belongsTo(ExampleItem, { foreignKey: 'example_id', as: 'example' });