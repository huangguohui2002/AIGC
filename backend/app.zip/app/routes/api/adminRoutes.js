module.exports = {
	// 统计
	'GET /stats': 'AdminController.getStats',

	// 用户管理
	'GET /users': 'AdminController.getUsers',
	'POST /users': 'AdminController.createUser',
	'GET /users/:id': 'AdminController.getUserDetail',
	'PUT /users/:id': 'AdminController.updateUser',
	'PUT /users/:id/points': 'AdminController.adjustPoints',
	'PUT /users/:id/status': 'AdminController.updateUserStatus',
	'DELETE /users/:id': 'AdminController.deleteUser',

	// 订单
	'GET /orders': 'AdminController.getOrders',

	// 生成记录
	'GET /generations': 'AdminController.getGenerations',

	// 公告管理
	'GET /announcements': 'AdminController.getAnnouncements',
	'POST /announcements': 'AdminController.createAnnouncement',
	'PUT /announcements/:id': 'AdminController.updateAnnouncement',
	'DELETE /announcements/:id': 'AdminController.deleteAnnouncement',

	// 积分套餐管理
	'GET /points-packages': 'AdminController.getPackages',
	'POST /points-packages': 'AdminController.createPackage',
	'PUT /points-packages/:id': 'AdminController.updatePackage',
	'DELETE /points-packages/:id': 'AdminController.deletePackage',
	'DELETE /points-packages/:id/permanent': 'AdminController.hardDeletePackage',

	// 系统配置
	'GET /configs': 'AdminController.getConfigs',
	'PUT /configs': 'AdminController.updateConfigs',

	// AI 模型管理
	'GET /ai-models': 'AiModelController.getModels',
	'POST /ai-models': 'AiModelController.createModel',
	'PUT /ai-models/:id': 'AiModelController.updateModel',
	'DELETE /ai-models/:id': 'AiModelController.deleteModel',

	// 示例管理 - 查询全量数据（含未激活）
	'GET /examples/categories': 'ExampleController.adminGetCategories',
	'GET /examples': 'ExampleController.adminGetList',
};
