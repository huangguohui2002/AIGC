/**
 * AIGC 第三方大模型调用服务
 *
 * 支持接口：
 *   图片 - /v1/draw/completions    (sora-image, gpt-image-1.5, gpt-image-2)
 *   图片 - /v1/draw/nano-banana    (nano-banana-* 系列)
 *   视频 - /v1/video/sora-video    (sora-2)
 *   视频 - /v1/video/veo           (veo3.1-fast, veo3.1-pro)
 *
 * 生成流程：
 *   1. 提交任务 → 从首条 SSE 事件拿到 work_id（立即返回，不等完成）
 *   2. 轮询结果 → POST /v1/draw/result  带 work_id 查询最新状态
 */
const axios = require('axios');
const https = require('https');

/**
 * 各模型支持的前端可选参数配置
 *
 * aspectRatioOptions  - 支持的比例选项（null = 不展示比例选择器）
 * imageSizeOptions    - 支持的图片 K 数选项（null = 不展示 imageSize 选择器）
 * durationOptions     - 支持的视频时长选项（null = 不展示时长选择器）
 */
const MODEL_CAPABILITIES = {
	// ── GPT Image ──────────────────────────────────────────────────────
	'sora-image': {
		aspectRatioOptions: ['auto', '1:1', '3:2', '2:3'],
		imageSizeOptions: null,
		durationOptions: null
	},
	'gpt-image-1.5': {
		aspectRatioOptions: ['auto', '1:1', '3:2', '2:3'],
		imageSizeOptions: null,
		durationOptions: null
	},
	'gpt-image-2': {
		aspectRatioOptions: [
			'auto', '1:1', '3:2', '2:3', '16:9', '9:16',
			'5:4', '4:5', '4:3', '3:4', '21:9', '9:21',
			'1:3', '3:1', '2:1', '1:2'
		],
		imageSizeOptions: null,
		durationOptions: null
	},

	// ── Nano Banana（不支持 imageSize）─────────────────────────────────
	'nano-banana-fast': {
		aspectRatioOptions: ['auto', '1:1', '16:9', '9:16', '4:3', '3:4', '3:2', '2:3', '5:4', '4:5', '21:9'],
		imageSizeOptions: null,
		durationOptions: null
	},
	'nano-banana': {
		aspectRatioOptions: ['auto', '1:1', '16:9', '9:16', '4:3', '3:4', '3:2', '2:3', '5:4', '4:5', '21:9'],
		imageSizeOptions: null,
		durationOptions: null
	},

	// ── Nano Banana（支持 imageSize）───────────────────────────────────
	'nano-banana-2': {
		aspectRatioOptions: ['auto', '1:1', '16:9', '9:16', '4:3', '3:4', '3:2', '2:3', '5:4', '4:5', '21:9'],
		imageSizeOptions: ['1K', '2K', '4K'],
		durationOptions: null
	},
	'nano-banana-pro': {
		aspectRatioOptions: ['auto', '1:1', '16:9', '9:16', '4:3', '3:4', '3:2', '2:3', '5:4', '4:5', '21:9'],
		imageSizeOptions: ['1K', '2K', '4K'],
		durationOptions: null
	},
	'nano-banana-pro-vt': {
		aspectRatioOptions: ['auto', '1:1', '16:9', '9:16', '4:3', '3:4', '3:2', '2:3', '5:4', '4:5', '21:9'],
		imageSizeOptions: ['1K', '2K', '4K'],
		durationOptions: null
	},
	'nano-banana-pro-cl': {
		aspectRatioOptions: ['auto', '1:1', '16:9', '9:16', '4:3', '3:4', '3:2', '2:3', '5:4', '4:5', '21:9'],
		imageSizeOptions: ['1K', '2K', '4K'],
		durationOptions: null
	},
	'nano-banana-pro-vip': {
		aspectRatioOptions: ['auto', '1:1', '16:9', '9:16', '4:3', '3:4', '3:2', '2:3', '5:4', '4:5', '21:9'],
		imageSizeOptions: ['1K', '2K'], // 官方限定只支持 1K、2K
		durationOptions: null
	},
	'nano-banana-pro-4k-vip': {
		aspectRatioOptions: ['auto', '1:1', '16:9', '9:16', '4:3', '3:4', '3:2', '2:3', '5:4', '4:5', '21:9'],
		imageSizeOptions: ['4K'],       // 官方限定只支持 4K
		durationOptions: null
	},

	// ── Sora-2 视频（支持时长）─────────────────────────────────────────
	'sora-2': {
		aspectRatioOptions: ['16:9', '9:16'],
		imageSizeOptions: null,
		durationOptions: [10, 15] // 秒
	},

	// ── Veo 视频（不支持时长）──────────────────────────────────────────
	'veo3.1-fast': {
		aspectRatioOptions: ['16:9', '9:16'],
		imageSizeOptions: null,
		durationOptions: null
	},
	'veo3.1-pro': {
		aspectRatioOptions: ['16:9', '9:16'],
		imageSizeOptions: null,
		durationOptions: null
	}
};

/**
 * 获取模型的前端可选参数能力描述
 * @param {string} modelName
 * @returns {object|null}
 */
function getModelCapabilities(modelName) {
	return MODEL_CAPABILITIES[modelName] || null;
}

const SUBMIT_TIMEOUT_MS = 30000; // 提交任务只需拿到首条 SSE，30s 足够
const RESULT_TIMEOUT_MS = 30000; // 查询结果接口超时

// 部分 API 端点使用 IP 或 CDN 代理，Node.js TLS SNI 会报 unrecognized_name
// servername 设为空字符串禁止发送 SNI 扩展
const httpsAgent = new https.Agent({ servername: '' });

function _resolveTaskType(modelName, taskType) {
	if (taskType === 'image' || taskType === 'video') return taskType;
	if (typeof modelName !== 'string') return 'image';
	if (modelName === 'sora-2' || modelName.startsWith('veo')) return 'video';
	return 'image';
}

/**
 * 根据模型名称/任务类型确定 API 路径
 * @param {string} modelName
 * @param {'image'|'video'} [taskType]
 * @returns {string}
 */
function _getApiPath(modelName, taskType) {
	const resolvedTaskType = _resolveTaskType(modelName, taskType);
	if (resolvedTaskType === 'video') {
		if (typeof modelName === 'string' && modelName.startsWith('veo')) return '/v1/video/veo';
		return '/v1/video/sora-video';
	}
	if (typeof modelName === 'string' && modelName.startsWith('nano-banana')) return '/v1/draw/nano-banana';
	return '/v1/draw/completions';
}

function _normalizeEndpoint(apiEndpoint) {
	if (!apiEndpoint || typeof apiEndpoint !== 'string') {
		throw new Error('模型接口地址未配置');
	}
	return apiEndpoint.replace(/\/+$/, '');
}

function _buildSubmitUrl(apiEndpoint, path) {
	const endpoint = _normalizeEndpoint(apiEndpoint);
	return endpoint.endsWith(path) ? endpoint : `${endpoint}${path}`;
}

function _buildPollUrl(apiEndpoint, pollPath, submitPath) {
	const endpoint = _normalizeEndpoint(apiEndpoint);
	if (endpoint.endsWith(submitPath)) {
		return `${endpoint.slice(0, -submitPath.length)}${pollPath}`;
	}
	return `${endpoint}${pollPath}`;
}

function _createResultQueryError(message) {
	const err = new Error(message);
	err.name = 'ResultQueryFailed';
	return err;
}

function _extractJobId(payload) {
	if (!payload || typeof payload !== 'object') return '';
	if (typeof payload.id === 'string' && payload.id.trim()) return payload.id.trim();
	if (typeof payload.id === 'number') return String(payload.id);
	if (typeof payload.work_id === 'string' && payload.work_id.trim()) return payload.work_id.trim();
	if (typeof payload.workId === 'string' && payload.workId.trim()) return payload.workId.trim();
	if (typeof payload.data?.id === 'string' && payload.data.id.trim()) return payload.data.id.trim();
	if (typeof payload.data?.id === 'number') return String(payload.data.id);
	if (typeof payload.data?.work_id === 'string' && payload.data.work_id.trim()) return payload.data.work_id.trim();
	if (typeof payload.data?.workId === 'string' && payload.data.workId.trim()) return payload.data.workId.trim();
	return '';
}

function _extractSubmitError(payload) {
	if (!payload || typeof payload !== 'object') return '';
	if (typeof payload.error === 'string' && payload.error.trim()) return payload.error.trim();
	if (typeof payload.message === 'string' && payload.message.trim()) return payload.message.trim();
	if (payload.code !== undefined && payload.code !== 0) {
		if (typeof payload.msg === 'string' && payload.msg.trim()) return payload.msg.trim();
	}
	return '';
}

async function _submitJobJson(apiEndpoint, apiKey, path, body) {
	const url = _buildSubmitUrl(apiEndpoint, path);
	let response;

	try {
		response = await axios.post(url, body, {
			headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${apiKey}` },
			httpsAgent,
			timeout: SUBMIT_TIMEOUT_MS
		});
	} catch (error) {
		if (error.response) {
			const upstreamData = error.response.data;
			const upstreamMsg =
				(typeof upstreamData === 'string' && upstreamData) ||
				_extractSubmitError(upstreamData) ||
				upstreamData?.msg ||
				error.response.statusText ||
				'上游服务异常';
			throw new Error(`提交任务失败：${upstreamMsg}`);
		}
		throw new Error(`提交任务失败：${error.message || '请求上游失败'}`);
	}

	const workId = _extractJobId(response.data);
	if (workId) return workId;

	const submitError = _extractSubmitError(response.data);
	if (submitError) {
		throw new Error(`提交任务失败：${submitError}`);
	}

	console.error('[AigcService._submitJobJson] missing work id', {
		url,
		model: body?.model,
		response: response.data
	});
	throw new Error('提交任务失败：未获取到工作ID');
}

/**
 * 提交生成任务，从首条 SSE 事件中提取 work_id 后立即返回（不等待生成完成）
 *
 * @param {string} apiEndpoint  不带路径的基础地址，如 https://grsai.dakka.com.cn
 * @param {string} apiKey       Bearer token
 * @param {string} path         接口路径，如 /v1/draw/completions
 * @param {object} body         请求体
 * @returns {Promise<string>}   work_id
 */
function _submitJob(apiEndpoint, apiKey, path, body) {
	const url = _buildSubmitUrl(apiEndpoint, path);

	return axios
		.post(url, body, {
			headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${apiKey}` },
			responseType: 'stream',
			httpsAgent,
			timeout: SUBMIT_TIMEOUT_MS
		})
		.then(
			(response) =>
				new Promise((resolve, reject) => {
					let settled = false;
					let buffer = '';

					const settle = (fn, val) => {
						if (settled) return;
						settled = true;
						response.data.destroy();
						fn(val);
					};

					response.data.on('data', (chunk) => {
						if (settled) return;
						buffer += chunk.toString();
						const lines = buffer.split('\n');
						// 保留最后一行（可能不完整）继续累积
						buffer = lines.pop() || '';

						for (const line of lines) {
							const trimmed = line.trim();
							if (!trimmed) continue;
							const jsonStr = trimmed.startsWith('data:') ? trimmed.slice(5).trim() : trimmed;
							if (!jsonStr) continue;
							try {
								const parsed = JSON.parse(jsonStr);
								const workId = _extractJobId(parsed);
								if (workId) {
									settle(resolve, workId);
									return;
								}
								const submitError = _extractSubmitError(parsed);
								if (submitError) {
									settle(reject, new Error(`提交任务失败：${submitError}`));
									return;
								}
							} catch (e) {
								void e; // 跳过不可解析的行
							}
						}
					});

					response.data.on('end', () => {
						// 流正常结束时尝试解析剩余缓冲
						if (!settled && buffer.trim()) {
							const jsonStr = buffer.trim().startsWith('data:')
								? buffer.trim().slice(5).trim()
								: buffer.trim();
							try {
								const parsed = JSON.parse(jsonStr);
								const workId = _extractJobId(parsed);
								if (workId) {
									settle(resolve, workId);
									return;
								}
								const submitError = _extractSubmitError(parsed);
								if (submitError) {
									settle(reject, new Error(`提交任务失败：${submitError}`));
									return;
								}
							} catch (e) { void e; }
						}
						settle(reject, new Error('提交任务失败：未获取到工作ID'));
					});

					response.data.on('error', (err) => {
						// destroy() 触发的 ERR_STREAM_DESTROYED 可忽略
						if (err.code === 'ERR_STREAM_DESTROYED') return;
						settle(reject, new Error('提交任务失败：' + err.message));
					});
				})
		);
}

/**
 * 轮询结果统一走 /v1/draw/result（上游同一接口同时支持图片与视频任务）
 * @returns {string}
 */
function _getPollPath() {
	return '/v1/draw/result';
}

async function _submitJobJsonV2(apiEndpoint, apiKey, path, body) {
	const url = _buildSubmitUrl(apiEndpoint, path);
	let response;

	try {
		response = await axios.post(url, body, {
			headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${apiKey}` },
			httpsAgent,
			timeout: SUBMIT_TIMEOUT_MS
		});
	} catch (error) {
		if (error.response) {
			const upstreamData = error.response.data;
			const upstreamMsg =
				(typeof upstreamData === 'string' && upstreamData) ||
				_extractSubmitError(upstreamData) ||
				upstreamData?.msg ||
				error.response.statusText ||
				'上游服务异常';
			throw new Error(`提交任务失败：${upstreamMsg}`);
		}
		throw new Error(`提交任务失败：${error.message || '请求上游失败'}`);
	}

	const workId = _extractJobId(response.data);
	if (workId) return workId;

	const submitError = _extractSubmitError(response.data);
	if (submitError) {
		throw new Error(`提交任务失败：${submitError}`);
	}

	console.error('[AigcService._submitJobJsonV2] missing work id', {
		url,
		model: body?.model,
		response: response.data
	});
	throw new Error('提交任务失败：未获取到工作ID');
}

function _submitJobV2(apiEndpoint, apiKey, path, body) {
	if (body?.webHook === '-1') {
		return _submitJobJsonV2(apiEndpoint, apiKey, path, body);
	}

	const url = _buildSubmitUrl(apiEndpoint, path);

	return axios
		.post(url, body, {
			headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${apiKey}` },
			responseType: 'stream',
			httpsAgent,
			timeout: SUBMIT_TIMEOUT_MS
		})
		.then(
			(response) =>
				new Promise((resolve, reject) => {
					let settled = false;
					let buffer = '';

					const settle = (fn, val) => {
						if (settled) return;
						settled = true;
						response.data.destroy();
						fn(val);
					};

					const tryResolvePayload = (payload) => {
						const workId = _extractJobId(payload);
						if (workId) {
							settle(resolve, workId);
							return true;
						}

						const submitError = _extractSubmitError(payload);
						if (submitError) {
							settle(reject, new Error(`提交任务失败：${submitError}`));
							return true;
						}

						return false;
					};

					response.data.on('data', (chunk) => {
						if (settled) return;
						buffer += chunk.toString();
						const lines = buffer.split('\n');
						buffer = lines.pop() || '';

						for (const line of lines) {
							const trimmed = line.trim();
							if (!trimmed) continue;
							const jsonStr = trimmed.startsWith('data:') ? trimmed.slice(5).trim() : trimmed;
							if (!jsonStr) continue;

							try {
								if (tryResolvePayload(JSON.parse(jsonStr))) return;
							} catch (e) {
								void e;
							}
						}
					});

					response.data.on('end', () => {
						if (!settled && buffer.trim()) {
							const jsonStr = buffer.trim().startsWith('data:')
								? buffer.trim().slice(5).trim()
								: buffer.trim();

							try {
								if (tryResolvePayload(JSON.parse(jsonStr))) return;
							} catch (e) {
								void e;
							}
						}

						if (!settled) {
							console.error('[AigcService._submitJobV2] missing work id', {
								url,
								model: body?.model,
								buffer: buffer.trim().slice(0, 1000)
							});
						}

						settle(reject, new Error('提交任务失败：未获取到工作ID'));
					});

					response.data.on('error', (err) => {
						if (err.code === 'ERR_STREAM_DESTROYED') return;
						settle(reject, new Error(`提交任务失败：${err.message}`));
					});
				})
		);
}

/**
 * 提交图片生成任务
 *
 * @param {object} aiModel           AiModel 数据库记录
 * @param {string} aiModel.api_endpoint
 * @param {string} aiModel.api_key
 * @param {string} aiModel.model_name
 * @param {object} params            请求参数
 * @param {string} params.prompt        提示词（必填）
 * @param {string} [params.aspectRatio] 比例，如 "1:1"、"16:9"（前端统一字段，默认 auto）
 * @param {string} [params.imageSize]   图片 K 数，仅支持 imageSize 的 nano-banana 模型生效，如 "1K"
 * @param {number} [params.variants]    批量数量 1~2（draw/completions 用）
 * @param {string[]} [params.urls]      参考图 URL
 * @returns {Promise<string>}  work_id
 */
async function generateImage(aiModel, params) {
	const { prompt, variants, urls, aspectRatio, imageSize } = params;
	const { api_endpoint, api_key, model_name } = aiModel;
	const path = _getApiPath(model_name, 'image');
	const caps = MODEL_CAPABILITIES[model_name];

	let body;
	if (model_name.startsWith('nano-banana')) {
		body = {
			model: model_name,
			prompt,
			aspectRatio: aspectRatio || 'auto',
			// 仅在该模型支持 imageSize 时才传递此参数
			imageSize: caps?.imageSizeOptions ? (imageSize || caps.imageSizeOptions[0]) : undefined,
			urls: urls && urls.length ? urls : undefined
		};
	} else if (model_name === 'gpt-image-2') {
		// gpt-image-2 使用 aspectRatio 参数，并通过 webHook=-1 立即返回任务 ID
		body = {
			model: model_name,
			prompt,
			aspectRatio: aspectRatio || 'auto',
			urls: urls && urls.length ? urls : undefined,
			webHook: '-1'
		};
	} else {
		// draw/completions: sora-image, gpt-image-1.5
		// 前端统一传 aspectRatio，映射为第三方接口的 size 参数
		body = {
			model: model_name,
			prompt,
			size: aspectRatio || 'auto',
			variants: variants || 1,
			urls: urls && urls.length ? urls : undefined
		};
	}

	return _submitJobV2(api_endpoint, api_key, path, body);
}

/**
 * 提交视频生成任务
 *
 * @param {object} aiModel            AiModel 数据库记录
 * @param {string} aiModel.api_endpoint
 * @param {string} aiModel.api_key
 * @param {string} aiModel.model_name
 * @param {object} params             请求参数
 * @param {string} params.prompt      提示词（必填）
 * @param {string} [params.url]       sora-2 参考图 URL
 * @param {string} [params.aspectRatio]  比例，如 "16:9"
 * @param {number} [params.duration]  sora-2 视频时长（秒），10 或 15
 * @param {string} [params.size]      sora-2 清晰度 small/large
 * @param {string} [params.firstFrameUrl]  veo 首帧图片 URL
 * @param {string} [params.lastFrameUrl]   veo 尾帧图片 URL
 * @param {string[]} [params.urls]    veo 参考图片 URL（最多 3 张）
 * @returns {Promise<string>} work_id
 */
async function generateVideo(aiModel, params) {
	const { prompt, url, aspectRatio, duration, size, firstFrameUrl, lastFrameUrl, urls } = params;
	const { api_endpoint, api_key, model_name } = aiModel;
	const path = _getApiPath(model_name, 'video');

	let body;
	if (model_name.startsWith('veo')) {
		body = {
			model: model_name,
			prompt,
			firstFrameUrl: firstFrameUrl || undefined,
			lastFrameUrl: lastFrameUrl || undefined,
			urls: urls && urls.length ? urls : undefined,
			aspectRatio: aspectRatio || '16:9'
		};
	} else {
		// sora-2
		body = {
			model: model_name,
			prompt,
			url: url || undefined,
			aspectRatio: aspectRatio || '16:9',
			duration: duration || 10,
			size: size || 'small'
		};
	}

	return _submitJobV2(api_endpoint, api_key, path, body);
}

async function getJobResultV2(apiEndpoint, apiKey, workId, modelName, taskType) {
	const pollPath = _getPollPath();
	const submitPath = _getApiPath(modelName, taskType);
	const pollUrl = _buildPollUrl(apiEndpoint, pollPath, submitPath);

	let response;
	try {
		response = await axios.post(
			pollUrl,
			{ id: workId },
			{
				headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${apiKey}` },
				httpsAgent,
				timeout: RESULT_TIMEOUT_MS
			}
		);
	} catch (error) {
		if (error.response) {
			const status = error.response.status;
			const upstreamData = error.response.data;
			const upstreamMsg =
				(typeof upstreamData === 'string' && upstreamData) ||
				upstreamData?.msg ||
				error.response.statusText ||
				'上游服务异常';
			throw _createResultQueryError(`结果查询失败（HTTP ${status}）：${upstreamMsg}`);
		}
		throw _createResultQueryError(error.message || '结果查询失败');
	}

	const data = response.data;
	console.log(
		`[AigcService.getJobResult] work_id=${workId} poll_url=${pollUrl} response=${JSON.stringify(data)}`
	);
	if (data.code !== 0) {
		if (data.code === -22) throw _createResultQueryError('任务不存在');
		throw _createResultQueryError(data.msg || '获取结果失败');
	}

	return data.data;
}

module.exports = { generateImage, generateVideo, getJobResult: getJobResultV2, getModelCapabilities };
