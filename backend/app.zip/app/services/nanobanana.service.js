/**
 * nanobanana AI 生成服务
 * 对接 nanobanana API 执行图片/视频生成
 */
const axios = require('axios');
const https = require('https');

const nanoConfig = {
	apiUrl: process.env.NANOBANANA_API_URL,
	apiKey: process.env.NANOBANANA_API_KEY
};

const TIMEOUT_MS = 90000; // 90s 超时

// 若 NANOBANANA_API_URL 使用 IP 地址或自签证书，Node.js TLS SNI 会报错
// servername 设为空字符串禁止发送 SNI 扩展，避免 ssl3_read_bytes unrecognized_name 报错
const httpsAgent = new https.Agent({
	rejectUnauthorized: false,
	servername: ''
});

/**
 * 生成图片
 * @param {object} params
 * @param {string} params.prompt 提示词
 * @param {string} params.model 模型名称
 * @param {string} [params.orientation] 方向: landscape/portrait/square
 * @param {number} [params.count] 生成数量
 * @param {string} [params.reference_image] 参考图 URL
 * @returns {Promise<string|string[]>} count=1 返回单个 URL；count>1 返回 URL 数组
 */
async function generateImage({ prompt, model, orientation = 'landscape', count = 1, reference_image }) {
	const response = await axios.post(
		`${nanoConfig.apiUrl}/v1/generate/image`,
		{
			prompt,
			model,
			orientation,
			count,
			reference_image: reference_image || undefined
		},
		{
			headers: {
				'Authorization': `Bearer ${nanoConfig.apiKey}`,
				'Content-Type': 'application/json'
			},
			httpsAgent,
			timeout: TIMEOUT_MS
		}
	);

	const data = response.data;
	const payload = data?.data || {};
	const urls = [];

	if (Array.isArray(payload.urls)) {
		payload.urls.forEach((u) => {
			if (typeof u === 'string' && u.trim()) urls.push(u.trim());
		});
	}

	if (Array.isArray(payload.results)) {
		payload.results.forEach((item) => {
			const url =
				(typeof item?.url === 'string' && item.url.trim()) ||
				(typeof item?.result_url === 'string' && item.result_url.trim()) ||
				'';
			if (url) urls.push(url);
		});
	}

	if (typeof payload.url === 'string' && payload.url.trim()) {
		urls.push(payload.url.trim());
	}

	const uniqueUrls = Array.from(new Set(urls));
	if (!data?.success || uniqueUrls.length === 0) {
		throw new Error(data?.message || '图片生成失败');
	}

	return count > 1 ? uniqueUrls : uniqueUrls[0];
}

/**
 * 生成视频
 * @param {object} params
 * @param {string} params.prompt 提示词
 * @param {string} [params.reference_image] 参考图 URL
 * @returns {Promise<string>} 返回生成结果的 URL
 */
async function generateVideo({ prompt, reference_image }) {
	const response = await axios.post(
		`${nanoConfig.apiUrl}/v1/generate/video`,
		{
			prompt,
			reference_image: reference_image || undefined
		},
		{
			headers: {
				'Authorization': `Bearer ${nanoConfig.apiKey}`,
				'Content-Type': 'application/json'
			},
			httpsAgent,
			timeout: TIMEOUT_MS
		}
	);

	const data = response.data;
	if (!data?.success || !data?.data?.url) {
		throw new Error(data?.message || '视频生成失败');
	}

	return data.data.url;
}

module.exports = {
	generateImage,
	generateVideo
};
