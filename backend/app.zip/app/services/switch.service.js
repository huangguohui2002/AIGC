let disabled = false;

module.exports = {
	isDisabled,
	setDisabled,
};

function isDisabled() {
	return disabled;
}

function setDisabled(value) {
	disabled = Boolean(value);
	return disabled;
}
